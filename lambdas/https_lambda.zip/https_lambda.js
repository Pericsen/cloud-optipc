exports.handler = (event, context, callback) => {
    const queryParams = event.queryStringParameters || {};
    const path = event.path || '';
    
    let redirectUrl;

    console.log("EVENT: " + JSON.stringify(event, null, 2));
    
    if (queryParams.code) {
        console.log('Handling login callback');
        // Determinar si es admin o usuario normal basado en la URL actual
        redirectUrl = process.env.REDIRECT_ADMIN_URL;
        redirectUrl = `${redirectUrl}?code=${queryParams.code}`;
    } else {
        console.log('Handling logout');
        redirectUrl = process.env.LOGOUT_REDIRECT_URL;
        // redirectUrl = `https://${process.env.DOMAIN}.auth.us-east-1.amazoncognito.com/logout?client_id=${process.env.CLIENT_ID}&logout_uri=${encodeURIComponent(process.env.LOGOUT_REDIRECT_URL)}`;
    }

    const response = {
        statusCode: 302,
        headers: {
            Location: redirectUrl
        }
    };

    callback(null, response);
};